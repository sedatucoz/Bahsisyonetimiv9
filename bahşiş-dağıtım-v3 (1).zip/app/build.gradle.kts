import java.util.Base64
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.io.InputStream

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.bahsisyonetimi"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    // Dynamically decode debug.keystore from base64 if it's missing (e.g., on GitHub Actions)
    val debugKeystoreFile = file("${rootDir}/debug.keystore")
    val base64File = file("${rootDir}/debug.keystore.base64")
    if (!debugKeystoreFile.exists() && base64File.exists()) {
      try {
        val base64Text = base64File.readText().trim()
        val decodedBytes = Base64.getDecoder().decode(base64Text)
        debugKeystoreFile.writeBytes(decodedBytes)
      } catch (e: Exception) {
        println("Warning: Failed to decode debug.keystore from base64: ${e.message}")
      }
    }

    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: ""
      val keystoreFile = if (keystorePath.isNotEmpty()) file(keystorePath) else file("${rootDir}/my-upload-key.jks")
      if (keystoreFile.exists()) {
        storeFile = keystoreFile
        storePassword = System.getenv("STORE_PASSWORD")
        keyAlias = System.getenv("KEY_ALIAS") ?: "upload"
        keyPassword = System.getenv("KEY_PASSWORD")
      } else {
        // Fall back to debug configuration if the file is present
        if (debugKeystoreFile.exists()) {
          storeFile = debugKeystoreFile
          storePassword = "android"
          keyAlias = "androiddebugkey"
          keyPassword = "android"
        }
      }
    }
    create("debugConfig") {
      if (debugKeystoreFile.exists()) {
        storeFile = debugKeystoreFile
        storePassword = "android"
        keyAlias = "androiddebugkey"
        keyPassword = "android"
      }
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      
      // Use configured release signing config if available, otherwise fall back to built-in debug config
      val releaseConfig = signingConfigs.getByName("release")
      if (releaseConfig.storeFile != null && releaseConfig.storeFile!!.exists()) {
        signingConfig = releaseConfig
      } else {
        signingConfig = signingConfigs.getByName("debug")
      }
    }
    debug {
      // Use local debugConfig if present, otherwise fall back to built-in debug config
      val debugConfig = signingConfigs.getByName("debugConfig")
      if (debugConfig.storeFile != null && debugConfig.storeFile!!.exists()) {
        signingConfig = debugConfig
      } else {
        signingConfig = signingConfigs.getByName("debug")
      }
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
}

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  implementation(libs.firebase.auth)
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  implementation(libs.play.services.auth)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
}

tasks.register("printDebugFingerprints") {
  group = "verification"
  description = "Prints SHA-1 and SHA-256 fingerprints of the debug keystore."
  doLast {
    val debugKeystoreFile = file("${rootDir}/debug.keystore")
    if (debugKeystoreFile.exists()) {
      try {
        val keystore = KeyStore.getInstance(KeyStore.getDefaultType())
        val stream: InputStream = debugKeystoreFile.inputStream()
        try {
          keystore.load(stream, "android".toCharArray())
        } finally {
          stream.close()
        }
        val cert = keystore.getCertificate("androiddebugkey") as? X509Certificate
        if (cert != null) {
          val sha1Md = MessageDigest.getInstance("SHA-1")
          val sha1Digest = sha1Md.digest(cert.encoded)
          val sha1 = sha1Digest.joinToString(":") { b -> String.format("%02X", b) }

          val sha256Md = MessageDigest.getInstance("SHA-256")
          val sha256Digest = sha256Md.digest(cert.encoded)
          val sha256 = sha256Digest.joinToString(":") { b -> String.format("%02X", b) }

          println("\n--- DEBUG KEYSTORE SIGNING FINGERPRINTS ---")
          println("SHA-1   : $sha1")
          println("SHA-256 : $sha256")
          println("-----------------------------------------\n")
        }
      } catch (e: Exception) {
        println("Warning: Failed to read debug keystore details: ${e.message}")
        e.printStackTrace()
      }
    } else {
      println("Debug keystore file not found at ${debugKeystoreFile.absolutePath}")
    }
  }
}

