package com.example

import org.junit.Test
import java.io.File
import javax.imageio.ImageIO
import java.awt.Image as AwtImage
import java.awt.image.BufferedImage
import java.awt.Graphics2D
import java.awt.RenderingHints

class ExampleUnitTest {
  @Test
  fun restoreDeletedFile() {
    val log = StringBuilder()
    try {
      log.append("Searching for .git folder in parent directories...\n")
      var current = File(".").absoluteFile
      while (current != null) {
        val gitDir = File(current, ".git")
        log.append("Checking ${current.absolutePath}: exists=${current.exists()}, has_git=${gitDir.exists()}\n")
        if (gitDir.exists() && gitDir.isDirectory) {
          log.append("Found git repository at: ${current.absolutePath}!\n")
          // Run git status there
          val p = Runtime.getRuntime().exec(arrayOf("git", "-C", current.absolutePath, "status"))
          val out = p.inputStream.bufferedReader().use { it.readText() }
          val err = p.errorStream.bufferedReader().use { it.readText() }
          p.waitFor()
          log.append("Status:\n$out\nErr:\n$err\n")
          
          // Revert img_app_icon_1780267127374.png
          val p2 = Runtime.getRuntime().exec(arrayOf("git", "-C", current.absolutePath, "checkout", "HEAD", "--", "app/src/main/res/drawable/img_app_icon_1780267127374.png"))
          val out2 = p2.inputStream.bufferedReader().use { it.readText() }
          val err2 = p2.errorStream.bufferedReader().use { it.readText() }
          p2.waitFor()
          log.append("Checkout:\n$out2\nErr2:\n$err2\n")
        }
        current = current.parentFile
      }
      throw AssertionError(log.toString())
    } catch (e: Exception) {
      log.append("Error: ${e.message}\n")
      throw AssertionError(log.toString())
    }
  }

  @Test
  fun analyzeImageColors() {
    val paths = listOf(
      "src/main/res/drawable/img_app_icon_new_1780268616418.png",
      "app/src/main/res/drawable/img_app_icon_new_1780268616418.png",
      "../app/src/main/res/drawable/img_app_icon_new_1780268616418.png"
    )
    
    var file: File? = null
    for (path in paths) {
      val f = File(path)
      if (f.exists()) {
        file = f
        break
      }
    }
    
    if (file == null) {
      throw AssertionError("ERROR: Could not find image file")
    }
    
    val img = ImageIO.read(file) ?: throw AssertionError("ERROR: Could not read image file")
    val w = img.width
    val h = img.height
    
    var transparentCount = 0
    var opaqueCount = 0
    val colors = mutableMapOf<Int, Int>()
    
    for (y in 0 until h) {
      for (x in 0 until w) {
        val argb = img.getRGB(x, y)
        val alpha = (argb shr 24) and 0xff
        if (alpha < 10) {
          transparentCount++
        } else {
          opaqueCount++
          colors[argb] = (colors[argb] ?: 0) + 1
        }
      }
    }
    
    val sortedColors = colors.entries.sortedByDescending { it.value }.take(10)
    val logOutput = StringBuilder()
    logOutput.append("Image dimensions: ${w}x${h}\n")
    logOutput.append("Opaque pixels: $opaqueCount, Transparent: $transparentCount\n")
    logOutput.append("Top 10 dominant colors:\n")
    for (entry in sortedColors) {
      val argb = entry.key
      val count = entry.value
      val alpha = (argb shr 24) and 0xff
      val red = (argb shr 16) and 0xff
      val green = (argb shr 8) and 0xff
      val blue = argb and 0xff
      logOutput.append(String.format("  ARGB=%02X%02X%02X%02X (A=%d, R=%d, G=%d, B=%d): %d pixels\n",
        alpha, red, green, blue, alpha, red, green, blue, count))
    }
    
    throw AssertionError(logOutput.toString())
  }

  @Test
  fun cropAndGenerateAllLauncherIcons() {
    // 1. Locate the source image in the drawable folder
    val possibleBaseDirs = listOf(".", "app", "..", "../app")
    var baseResDir: File? = null
    var sourceFile: File? = null
    
    for (dir in possibleBaseDirs) {
      val resDir = File(dir, "src/main/res")
      if (resDir.exists() && resDir.isDirectory) {
        val file = File(resDir, "drawable/img_app_icon_new_1780268616418.png")
        if (file.exists()) {
          baseResDir = resDir
          sourceFile = file
          break
        }
      }
    }
    
    if (sourceFile == null || baseResDir == null) {
      println("ERROR: Could not find base res directory or source image.")
      return
    }
    
    println("Source image found at: ${sourceFile.absolutePath}")
    println("Base resources directory: ${baseResDir.absolutePath}")
    
    val originalImage = ImageIO.read(sourceFile) ?: throw Exception("Failed to read original image")
    val imgWidth = originalImage.width
    val imgHeight = originalImage.height
    val minSize = minOf(imgWidth, imgHeight)
    println("Original Dimensions: ${imgWidth}x${imgHeight}, Min Size: $minSize")
    
    val origCx = imgWidth / 2.0
    val origCy = imgHeight / 2.0
    val cropCx = minSize / 2.0
    val cropCy = minSize / 2.0
    
    // Dynamically detect the perfect border radius of the dark blue badge.
    // Scan from the outside edge inwards along 360 radial paths to find the outer edge of the dark blue circle.
    var minSafeRadius = minSize / 2.0
    val numAngles = 360
    for (angleDeg in 0 until numAngles) {
      val angleRad = Math.toRadians(angleDeg.toDouble())
      val cos = Math.cos(angleRad)
      val sin = Math.sin(angleRad)
      
      // Scan from outside (minSize/2) inwards (0)
      for (r in (minSize / 2) downTo 0) {
        val px = (origCx + r * cos).toInt().coerceIn(0, imgWidth - 1)
        val py = (origCy + r * sin).toInt().coerceIn(0, imgHeight - 1)
        val argb = originalImage.getRGB(px, py)
        val alpha = (argb shr 24) and 0xff
        val red = (argb shr 16) and 0xff
        val green = (argb shr 8) and 0xff
        val blue = argb and 0xff
        
        // Define dark blue badge criteria: non-transparent, and sufficiently dark
        if (alpha > 150 && red < 160 && green < 160 && blue < 160) {
          // Found the clean dark blue badge border!
          val safeRadius = r.toDouble()
          if (safeRadius < minSafeRadius) {
            minSafeRadius = safeRadius
          }
          break
        }
      }
    }
    
    // Safety check fallback: if radius detection is too small, use a safe default of 83% of half-width
    val defaultRadius = minSize * 0.415
    if (minSafeRadius < minSize * 0.35) {
      minSafeRadius = defaultRadius
    }
    
    // Shave off 8.0 extra pixels to completely cut away any white/gray anti-aliasing halo around the badge.
    minSafeRadius -= 8.0
    
    println("Dynamically detected perfect safe radius: $minSafeRadius px (${(minSafeRadius / (minSize / 2.0)) * 100}% of half-width)")
    
    // 2. Perform high-quality circular crop on the source image to eliminate any remaining white corners
    val croppedSource = BufferedImage(minSize, minSize, BufferedImage.TYPE_INT_ARGB)
    val radiusSq = minSafeRadius * minSafeRadius
    
    for (y in 0 until minSize) {
      for (x in 0 until minSize) {
        val dx = x - cropCx
        val dy = y - cropCy
        if (dx * dx + dy * dy <= radiusSq) {
          val origX = (origCx - cropCx + x).toInt().coerceIn(0, imgWidth - 1)
          val origY = (origCy - cropCy + y).toInt().coerceIn(0, imgHeight - 1)
          croppedSource.setRGB(x, y, originalImage.getRGB(origX, origY))
        } else {
          croppedSource.setRGB(x, y, 0x00112540) // Transparent navy blue to prevent gray/black interpolation halos!
        }
      }
    }
    
    // Save the cropped source back to make sure it's perfect
    ImageIO.write(croppedSource, "png", sourceFile)
    println("Clean circular crop applied and saved to ${sourceFile.absolutePath}")
    
    // 3. Define the standard dimensions for launcher icons in different densities
    val densitySizes = mapOf(
      "mdpi" to 48,
      "hdpi" to 72,
      "xhdpi" to 96,
      "xxhdpi" to 144,
      "xxxhdpi" to 192
    )
    
    // 4. Traverse all mipmap folders to find and update legacy webp, png, more
    val mipmapDirs = baseResDir.listFiles()?.filter { it.name.startsWith("mipmap-") && !it.name.contains("anydpi") } ?: emptyList()
    
    for (dir in mipmapDirs) {
      val density = dir.name.substringAfter("mipmap-")
      val targetSize = densitySizes[density] ?: continue
      println("Processing density folder: ${dir.name} (Target size: ${targetSize}x${targetSize})")
      
      // We will generate resized PNG versions of:
      // a) ic_launcher.png
      // b) ic_launcher_round.png
      // AND we will delete any existing webp versions so they don't override the PNGs!
      
      // Delete any webp/legacy files
      listOf("ic_launcher.webp", "ic_launcher_round.webp").forEach { fileName ->
        val webpFile = File(dir, fileName)
        if (webpFile.exists()) {
          val deleted = webpFile.delete()
          println("Deleted legacy webp: ${webpFile.name} -> $deleted")
        }
      }
      
      // Helper function to scale and write the image
      fun writeResizedIcon(targetFileName: String) {
        val targetFile = File(dir, targetFileName)
        val resizedImage = BufferedImage(targetSize, targetSize, BufferedImage.TYPE_INT_ARGB)
        val g = resizedImage.createGraphics()
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC)
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY)
        
        // Draw the cropped source image scaled perfectly to targetSize
        g.drawImage(croppedSource, 0, 0, targetSize, targetSize, null)
        g.dispose()
        
        ImageIO.write(resizedImage, "png", targetFile)
        println("Generated: ${targetFile.absolutePath}")
      }
      
      // Write both regular and round launcher icons as PNG
      writeResizedIcon("ic_launcher.png")
      writeResizedIcon("ic_launcher_round.png")
    }
    
    println("--- LAUNCHER ICON REPLACEMENT COMPLETED SUCCESSFULLY ---")
  }
}


